<footer class="section">
		<div class="center black-text">&copy; Copyright 2024 Nabin pizza</div>
	</footer>
</body>