<?php 
    include('config/db_connect.php');

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $pizza = null;


    if(isset($_POST['delete'])){
        $id_to_delete = mysqli_real_escape_string($conn, $_POST['id_to_delete']);

        if($id_to_delete){
    
            $sql = "DELETE FROM pizzas WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt === false) {
                die('SQL Preparation error: ' . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt, 'i', $id_to_delete);

            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_close($stmt);
                mysqli_close($conn);
 
                header('Location: index.php');
                exit();
            } else {
                die('SQL Execution error: ' . mysqli_error($conn));
            }
        } else {
            echo 'Invalid ID<br>';
        }
    }

    if(isset($_GET['id'])){
        $id = mysqli_real_escape_string($conn, $_GET['id']);

        $sql = "SELECT * FROM pizzas WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt === false) {
            die('SQL Preparation error: ' . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, 'i', $id);

        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
            $pizza = mysqli_fetch_assoc($result);

            mysqli_free_result($result);
            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        } else {
            die('Query error: ' . mysqli_error($conn));
        }
    }
?>

<!DOCTYPE html>
<html>

    <?php include('templates/header.php'); ?>

    <div class="container center black-text">
        <?php if($pizza): ?>
            <h4><?php echo htmlspecialchars($pizza['title']); ?></h4>
            <p>Created by <?php echo htmlspecialchars($pizza['email']); ?></p>
            <p><?php echo htmlspecialchars($pizza['created_at']); ?></p>
            <h5>Ingredients:</h5>
            <p><?php echo htmlspecialchars($pizza['ingredients']); ?></p>

            <form action="details.php"  method="POST">
                <input type="hidden" name="id_to_delete" value="<?php echo htmlspecialchars($pizza['id']); ?>">
                <input type="submit" name="delete" value="Delete" class="btn brand z-depth-2">
            </form>
            
        <?php else: ?>
            <h5>No Such Pizza Exists.</h5>
        <?php endif ?>
    </div>

    <?php include('templates/footer.php'); ?>

</html>
