<?php 

	$conn = mysqli_connect('localhost', 'nabin', 'test1234', 'ninja pizza');

	if(!$conn){
		echo 'Connection error: '. mysqli_connect_error();
	}

?>